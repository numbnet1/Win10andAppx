#include "crtheaders.h"
#include TIME_H

struct tm *localtime_r(const time_t *, struct tm *);
