#ifndef FNMATCH_H
#define FNMATCH_H 1

int fnmatch(const char *pattern, const char *string, int flags);


#endif
