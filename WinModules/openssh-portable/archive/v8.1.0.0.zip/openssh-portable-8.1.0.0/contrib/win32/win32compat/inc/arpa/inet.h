#ifndef COMPAT_INET_H
#define COMPAT_INET_H 1

/* Compatibility header to avoid lots of #ifdef _WIN32's in includes.h */

#endif
