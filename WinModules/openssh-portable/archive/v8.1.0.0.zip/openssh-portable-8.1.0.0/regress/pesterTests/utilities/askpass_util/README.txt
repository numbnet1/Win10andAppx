askpass_util is a test utility to be used in conjunction with SSH_ASKPASS in ssh. 

It simply spits out environment variable stored in ASKPASS_PASSWORD.