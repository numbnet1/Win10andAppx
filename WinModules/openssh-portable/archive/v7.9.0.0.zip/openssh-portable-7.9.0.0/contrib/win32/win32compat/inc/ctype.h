#include "crtheaders.h"
#include CTYPE_H

#define isascii __isascii

