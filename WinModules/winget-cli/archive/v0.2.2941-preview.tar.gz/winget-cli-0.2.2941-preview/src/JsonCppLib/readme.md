## JsonCppLib

Do not change code under this directory. JsonCppLib contains the amalgamated version of [jsoncpp](https://github.com/open-source-parsers/jsoncpp) source code commit [9be589598595963f94ba264d7b416d0533421106](https://github.com/open-source-parsers/jsoncpp/commit/9be589598595963f94ba264d7b416d0533421106).
It is created using command from the root of the jsoncpp project:

    python amalgamate.py

The outcome is then copied into the JsonCppLib project.

The JsonCppLib.vcxproj and JsonCppLib.vcxproj.filters are created to make jsoncpp code compiled as part of the AppInstallerClient solution.
