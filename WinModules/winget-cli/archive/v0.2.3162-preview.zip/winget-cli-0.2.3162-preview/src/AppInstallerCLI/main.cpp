﻿// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
#include <AppInstallerCLICore.h>

int wmain(int argc, wchar_t const** argv)
{
    return AppInstaller::CLI::CoreMain(argc, argv);
}
