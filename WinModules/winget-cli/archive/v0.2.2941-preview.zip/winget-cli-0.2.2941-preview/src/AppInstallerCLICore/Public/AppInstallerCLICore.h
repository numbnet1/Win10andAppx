// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
#pragma once

namespace AppInstaller::CLI
{
    int CoreMain(int argc, wchar_t const** argv);
}
